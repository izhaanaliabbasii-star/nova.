package com.nova.assistant

import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore

/**
 * "find my pdf [name]" / "find file [name]" -> searches device storage.
 * On Android 11+, seeing files outside Nova's own folder requires the
 * special "All files access" permission (MANAGE_EXTERNAL_STORAGE) — a
 * user has to grant this manually via Settings (Play Store treats it as
 * a sensitive permission), which is why there's a dedicated button for it
 * in the app rather than a normal runtime prompt.
 */
object FileFinder {

    fun find(ctx: Context, query: String): String {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            return "I need \"All files access\" first — tap \"Enable file search\" on the Nova home screen, then try again."
        }

        val cleanQuery = query
            .replace(Regex("(?i)find (my )?(pdf|file|document)s?"), "")
            .trim()

        val mimeHint = if (query.contains("pdf", ignoreCase = true)) "application/pdf" else null

        val projection = arrayOf(
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.DATA
        )
        val selection = StringBuilder()
        val args = mutableListOf<String>()
        if (mimeHint != null) {
            selection.append("${MediaStore.Files.FileColumns.MIME_TYPE} = ?")
            args.add(mimeHint)
        }
        if (cleanQuery.isNotBlank()) {
            if (selection.isNotEmpty()) selection.append(" AND ")
            selection.append("${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ?")
            args.add("%$cleanQuery%")
        }

        val results = mutableListOf<String>()
        try {
            ctx.contentResolver.query(
                MediaStore.Files.getContentUri("external"),
                projection,
                if (selection.isEmpty()) null else selection.toString(),
                if (args.isEmpty()) null else args.toTypedArray(),
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                while (cursor.moveToNext() && results.size < 5) {
                    cursor.getString(nameIdx)?.let { results.add(it) }
                }
            }
        } catch (e: Exception) {
            return "Couldn't search files: ${e.message}"
        }

        return when {
            results.isEmpty() -> "I couldn't find any files matching \"$cleanQuery\"."
            results.size == 1 -> "Found it: ${results[0]}."
            else -> "Found ${results.size} matches, most recent first: " + results.joinToString(", ")
        }
    }
}

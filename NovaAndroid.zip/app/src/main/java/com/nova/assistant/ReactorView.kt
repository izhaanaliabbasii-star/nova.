package com.nova.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * A simple pulsing glow ring, drawn with Canvas (no image assets needed).
 * Purely decorative — sets the "AI waking up" mood during onboarding.
 */
class ReactorView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var pulse = 0f
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        color = Color.parseColor("#7C4DFF")
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2200
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = LinearInterpolator()
            addUpdateListener {
                pulse = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = (width.coerceAtMost(height) / 2f) * 0.55f
        val radius = baseRadius + (pulse * 18f)

        glowPaint.shader = RadialGradient(
            cx, cy, radius * 1.8f,
            intArrayOf(Color.parseColor("#337C4DFF"), Color.TRANSPARENT),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius * 1.8f, glowPaint)

        ringPaint.alpha = (150 + pulse * 100).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, radius, ringPaint)
        canvas.drawCircle(cx, cy, radius * 0.7f, ringPaint)
    }
}

package com.nova.assistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import java.util.Locale

/**
 * "message/text/whatsapp <name/number> <message>" opens the chat with the
 * text pre-filled. Android does not allow apps to silently auto-send SMS or
 * WhatsApp messages on someone's behalf without extra permissions/review, so
 * this gets you one tap away instead of zero — which is also the safer,
 * Play-Store-friendly way to do it.
 */
object MessageSender {

    fun tryHandle(ctx: Context, raw: String): String? {
        val t = raw.trim()
        val lower = t.lowercase(Locale.ROOT)

        val whatsappPrefix = listOf("whatsapp ", "message ", "text ")
        val prefix = whatsappPrefix.firstOrNull { lower.startsWith(it) } ?: return null

        val rest = t.substring(prefix.length).trim()
        // split "<contact> <message...>" on the first space
        val parts = rest.split(" ", limit = 2)
        if (parts.size < 2) return "Who should I message, and what should it say?"
        val contact = parts[0]
        val message = parts[1]

        return if (contact.any { it.isDigit() } && contact.count { it.isDigit() } >= 7) {
            sendWhatsAppToNumber(ctx, contact, message)
        } else {
            val number = ContactLookup.findNumber(ctx, contact)
            if (number != null) sendWhatsAppToNumber(ctx, number, message)
            else openWhatsAppSearch(ctx, contact, message)
        }
    }

    private fun sendWhatsAppToNumber(ctx: Context, phone: String, message: String): String {
        val cleanPhone = phone.filter { it.isDigit() || it == '+' }
        return try {
            val uri = Uri.parse("https://wa.me/$cleanPhone?text=" + Uri.encode(message))
            val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            "Opening WhatsApp with your message to $phone ready — just hit send."
        } catch (e: ActivityNotFoundException) {
            "Couldn't open WhatsApp — is it installed?"
        }
    }

    private fun openWhatsAppSearch(ctx: Context, name: String, message: String): String {
        // No direct "open chat by contact name" intent exists; this opens
        // WhatsApp itself with the message ready to paste, or falls back to
        // the normal Android share sheet with WhatsApp pre-selected.
        return try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
                setPackage("com.whatsapp")
            }
            ctx.startActivity(sendIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Opening WhatsApp with your message — pick $name's chat and hit send."
        } catch (e: ActivityNotFoundException) {
            "Couldn't open WhatsApp — is it installed?"
        }
    }
}

package com.nova.assistant

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * "log pushups" / "log water" -> increments today's counter for that habit.
 * "how many pushups today" -> reads it back.
 * Keyed by habitName + date, so counts reset naturally each day.
 */
object HabitTracker {

    private const val PREFS = "nova_habits"

    private fun todayKey(habit: String): String {
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        return habit.trim().lowercase().replace(" ", "_") + "_" + day
    }

    fun log(ctx: Context, habit: String, amount: Int = 1): String {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = todayKey(habit)
        val newCount = prefs.getInt(key, 0) + amount
        prefs.edit().putInt(key, newCount).apply()
        return "Logged. That's $newCount $habit today."
    }

    fun count(ctx: Context, habit: String): String {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val count = prefs.getInt(todayKey(habit), 0)
        return "You've logged $count $habit today."
    }
}

package com.nova.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Real weather, no API key needed: uses the device's last known location
 * (plain LocationManager, no Play Services dependency) + Open-Meteo's free
 * public API.
 */
object WeatherClient {

    fun getWeather(ctx: Context): String {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return "I need location permission to check your local weather. Grant it in Settings > Apps > Nova > Permissions."
        }

        val (lat, lon) = lastKnownLocation(ctx)
            ?: return "I couldn't get your location yet — try again in a moment (make sure location is turned on)."

        return try {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code,wind_speed_10m&temperature_unit=celsius"
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            val body = conn.inputStream.bufferedReader().readText()
            conn.disconnect()

            val current = JSONObject(body).getJSONObject("current")
            val temp = current.getDouble("temperature_2m")
            val wind = current.getDouble("wind_speed_10m")
            val code = current.getInt("weather_code")
            "It's ${temp.toInt()} degrees celsius with ${describeCode(code)}, wind at ${wind.toInt()} km/h."
        } catch (e: Exception) {
            "I couldn't reach the weather service — check your internet connection."
        }
    }

    private fun lastKnownLocation(ctx: Context): Pair<Double, Double>? {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true)
        for (provider in providers) {
            try {
                val loc = lm.getLastKnownLocation(provider) ?: continue
                return loc.latitude to loc.longitude
            } catch (e: SecurityException) {
                return null
            }
        }
        return null
    }

    // WMO weather codes -> plain English (subset covering the common ones)
    private fun describeCode(code: Int): String = when (code) {
        0 -> "clear sky"
        1, 2, 3 -> "partly cloudy"
        45, 48 -> "fog"
        51, 53, 55 -> "light drizzle"
        61, 63, 65 -> "rain"
        71, 73, 75 -> "snow"
        80, 81, 82 -> "rain showers"
        95, 96, 99 -> "thunderstorms"
        else -> "mixed conditions"
    }
}

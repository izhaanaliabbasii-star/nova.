package com.nova.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * "call [name or number]" — a real phone call, not a workaround.
 * Needs CALL_PHONE permission (requested at runtime in MainActivity);
 * falls back to opening the dialer pre-filled if permission isn't granted.
 */
object PhoneDialer {

    fun tryHandle(ctx: Context, raw: String): String? {
        val t = raw.lowercase(Locale.ROOT).trim()
        if (!t.startsWith("call ") && !t.startsWith("phone ") && !t.startsWith("dial ")) return null

        val target = raw.substringAfter(" ", "").trim()
        if (target.isBlank()) return "Who should I call?"

        val number = if (target.any { it.isDigit() } && target.count { it.isDigit() } >= 7) {
            target
        } else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return "I need Contacts permission to call $target by name — grant it in Settings > Apps > Nova > Permissions, or say a phone number instead."
        } else {
            ContactLookup.findNumber(ctx, target)
                ?: return "I couldn't find $target in your contacts."
        }

        val hasPermission = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED

        return try {
            val intent = Intent(
                if (hasPermission) Intent.ACTION_CALL else Intent.ACTION_DIAL,
                Uri.parse("tel:" + Uri.encode(number))
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            if (hasPermission) "Calling $target." else "Opening the dialer for $target — grant call permission so I can dial directly next time."
        } catch (e: Exception) {
            "Couldn't place the call: ${e.message}"
        }
    }
}
